
import sqlite3

def get_user(user_id):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    # VULNERABILITY: SQL Injection
    cursor.execute("SELECT * FROM users WHERE id = '" + user_id + "'")
    return cursor.fetchone()
