
import os

def ping_host(hostname):
    # VULNERABILITY: Command Injection
    os.system("ping -c 1 " + hostname)
