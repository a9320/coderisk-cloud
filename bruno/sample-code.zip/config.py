
# VULNERABILITY: Hardcoded Secret
API_KEY = "sk-live-1234567890abcdef"
DATABASE_PASSWORD = "admin123"
